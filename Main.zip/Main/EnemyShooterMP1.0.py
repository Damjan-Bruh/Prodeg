import pygame as pg
import random as rand
from pygame import mixer
import tkinter as tk

root = tk.Tk()

frame = tk.Frame()
frame.pack()

def multiplayer():

    mixer.init()

    pg.font.init()

    font = pg.font.Font("freesansbold.ttf", 32)

    w = 1000
    h = 750

    red_x = rand.randint(0, 925)
    red_y = 550

    blue_x = rand.randint(0, 925)
    blue_y = 550

    enemy_x = rand.randint(0,925)
    enemy_y = 250

    font_red_x = 15
    font_red_y = 55

    font_blue_x = 850
    font_blue_y = 55

    player_speed = 7

    time_speed = 5

    grass_width = 1000
    grass_height = 300

    player_width = 75
    player_height = 200

    enemy_width = 75
    enemy_height = 200

    time_width = 1500
    time_height = 50

    red_score = 0
    blue_score = 0

    window = pg.display.set_mode((w, h))
    pg.display.set_caption('Enemy Shooter MP 1.0')

    bg = pg.transform.scale(pg.image.load('bg.png'), (w, h))

    player_red = pg.transform.scale(pg.image.load('player_red.png'), (player_width, player_height))

    player_blue = pg.transform.scale(pg.image.load('player_blue.png'), (player_width, player_height))

    enemy = pg.transform.scale(pg.image.load('enemy.png'), (enemy_width, enemy_height))

    def draw(grass_1, time, font_red_x, font_red_y, red_score, font_blue_x, font_blue_y, blue_score):

        window.blit(bg, (0, 0))

        pg.draw.rect(window, 'blue', time)

        pg.draw.rect(window, 'lime', grass_1)

        score_red = font.render(f"Score: {str(red_score)}", True, [255, 0, 0])
        window.blit(score_red, (font_red_x, font_red_y))

        score_blue = font.render(f"Score: {str(blue_score)}", True, [0, 0, 255])
        window.blit(score_blue, (font_blue_x, font_blue_y))

        pg.display.update()

    def main(red_x, red_y, blue_x, blue_y, enemy_x, enemy_y, font_red_x, font_red_y, red_score, font_blue_x, font_blue_y, blue_score):

        run = True

        time = pg.Rect(950, 0, time_width, time_height)

        grass_1 = pg.Rect(0, 450, grass_width, grass_height)

        while run:

            time.x -= time_speed

            if time.x <= 0:
                
                run = False

            keys = pg.key.get_pressed()

            #player_red

            if keys[pg.K_a]:

                red_x -= player_speed

            if keys[pg.K_d]:

                red_x += player_speed

            if keys[pg.K_s]:

                if red_x + 35 >= enemy_x and red_x + 35 <= enemy_x + enemy_width:

                    red_score += 1
                    enemy_x = rand.randint(0, 925)
                    time.x += w - time.x

                    mixer.music.load('gunshot.mp3')
                    mixer.music.play()

                    pg.display.update()

            window.blit(player_red, (red_x, red_y))

            #player_blue

            if keys[pg.K_LEFT]:

                blue_x -= player_speed

            if keys[pg.K_RIGHT]:

                blue_x += player_speed

            if keys[pg.K_DOWN]:

                if blue_x + 35 >= enemy_x and blue_x + 35 <= enemy_x + enemy_width:

                    blue_score += 1
                    enemy_x = rand.randint(0, 925)
                    time.x += w - time.x

                    mixer.music.load('gunshot.mp3')
                    mixer.music.play()

                    pg.display.update()

            window.blit(player_blue, (blue_x, blue_y))

            #enemy

            window.blit(enemy, (enemy_x, enemy_y))

            pg.display.flip()

            for event in pg.event.get():

                if event.type == pg.QUIT:

                    quit()

            draw(grass_1, time, font_red_x, font_red_y, red_score, font_blue_x, font_blue_y, blue_score)

        pg.quit()

    if __name__ == '__main__':

        main(red_x, red_y, blue_x, blue_y, enemy_x, enemy_y, font_red_x, font_red_y, red_score, font_blue_x, font_blue_y, blue_score)

def singleplayer():

    mixer.init()

    pg.font.init()

    font = pg.font.Font("freesansbold.ttf", 32)

    w = 1000
    h = 750

    red_x = rand.randint(0, 925)
    red_y = 550

    enemy_x = rand.randint(0,925)
    enemy_y = 250

    font_red_x = 15
    font_red_y = 55

    player_speed = 5
    fast_speed = 10

    time_speed = 7

    grass_width = 1000
    grass_height = 300

    player_width = 75
    player_height = 200

    enemy_width = 75
    enemy_height = 200

    time_width = 1500
    time_height = 50

    red_score = 0

    window = pg.display.set_mode((w, h))
    pg.display.set_caption('Enemy Shooter MP 1.0')

    bg = pg.transform.scale(pg.image.load('bg.png'), (w, h))

    player_red = pg.transform.scale(pg.image.load('player_red.png'), (player_width, player_height))

    enemy = pg.transform.scale(pg.image.load('enemy.png'), (enemy_width, enemy_height))

    def draw(grass_1, grass_2, grass_3, time, font_red_x, font_red_y, red_score):

        window.blit(bg, (0, 0))

        pg.draw.rect(window, 'blue', time)

        pg.draw.rect(window, 'lime', grass_1)
        pg.draw.rect(window, 'yellow', grass_2)
        pg.draw.rect(window, 'red', grass_3)

        score_red = font.render(f"Score: {str(red_score)}", True, [255, 0, 0])
        window.blit(score_red, (font_red_x, font_red_y))

        pg.display.update()

    def main(red_x, red_y, enemy_x, enemy_y, font_red_x, font_red_y, red_score):

        run = True

        time = pg.Rect(950, 0, time_width, time_height)

        grass_1 = pg.Rect(0, 450, grass_width, grass_height)
        grass_2 = pg.Rect(-1000, 450, grass_width, grass_height)
        grass_3 = pg.Rect(-1000, 450, grass_width, grass_height)

        while run:

            time.x -= time_speed

            if time.x <= 0:
                
                run = False

            keys = pg.key.get_pressed()

            if keys[pg.K_a]:

                red_x -= player_speed

            if keys[pg.K_d]:

                red_x += player_speed

            if keys[pg.K_LEFT]:

                red_x -= fast_speed

            if keys[pg.K_RIGHT]:

                red_x += fast_speed

            if keys[pg.K_SPACE]:

                if red_x + 35 >= enemy_x and red_x + 35 <= enemy_x + enemy_width:

                    red_score += 1
                    enemy_x = rand.randint(0, 925)
                    time.x += w - time.x

                    mixer.music.load('gunshot.mp3')
                    mixer.music.play()

                    pg.display.update()

            window.blit(player_red, (red_x, red_y))

            window.blit(enemy, (enemy_x, enemy_y))

            pg.display.flip()

            if red_score >= 100:

                grass_2.x = 0

            if red_score >= 200:

                grass_3.x = 0

            for event in pg.event.get():

                if event.type == pg.QUIT:

                    quit()

            draw(grass_1, grass_2, grass_3, time, font_red_x, font_red_y, red_score)

        pg.quit()

    if __name__ == '__main__':

        main(red_x, red_y, enemy_x, enemy_y, font_red_x, font_red_y, red_score)

menu = tk.PhotoImage(file = 'menu.png')

singleplayer_image = tk.PhotoImage(file = 'singleplayer.png')

multiplayer_image = tk.PhotoImage(file = 'multiplayer.png')

menu_button = tk.Button(frame, image = menu)
menu_button.pack(side = tk.BOTTOM)

sp = tk.Button(frame, image = singleplayer_image, command = singleplayer)
sp.pack(side = tk.LEFT)

mp = tk.Button(frame, image = multiplayer_image, command = multiplayer)
mp.pack(side = tk.RIGHT)

root.mainloop()
